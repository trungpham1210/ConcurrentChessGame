rootProject.name = "CS-4348-Project-1-Template"

