package edu.utdallas.cs4348;

import java.util.List;

public class ChessMatch {

    // Do not modify these, and do not add any other member variables to this class
    private ChessMove playerOneMove;
    private ChessMove playerTwoMove;

    // Your private Runnable implementations here

    public MoveRecord playMoves(List<ChessMove> playerOneMoves, List<ChessMove> playerTwoMoves) {
        MoveRecord moveRecord = new MoveRecord();

        // Your code here. :)

        return moveRecord;
    }
}
